package com.androidatc.final_project_tic_tac_toe

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import kotlinx.android.synthetic.main.activity_about_page.*

class About_Page : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_about_page)
    }

    fun about(view: View)
    {
       info.text="This version of Tic Tac Toe was created for a final project for an Android " +
               "development class in October 2021."
    }

    fun rules(view: View)
    {
        info.text="The rules are simple: the first player to get three Xs or three Os in a row win." +
                "Players take turns to place their respective marks on the board. One player is X, " +
                "the other player is O"
    }
}