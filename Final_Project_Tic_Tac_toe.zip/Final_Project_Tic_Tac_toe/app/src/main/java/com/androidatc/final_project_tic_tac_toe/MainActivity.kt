// Created by Zechary Harper II version 1.0 Course Final Project Tic-Tac-Toe
package com.androidatc.final_project_tic_tac_toe


import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.Button
import androidx.appcompat.app.AlertDialog
import com.androidatc.final_project_tic_tac_toe.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {
    // Keep Track of whose turn it is
    enum class Turn {
        EXS,
        OHS
    }
// Set variables
    private var firstTurn = Turn.EXS
    private var  currentTurn = Turn.EXS
    private var boardList = mutableListOf<Button>()
    private var xCount = 0
    private var oCount = 0

    private lateinit var binding: ActivityMainBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)
        initBoard()
    }

    fun goToAboutPage(view: View)
    {
        var intent = Intent(this,About_Page::class.java)
        startActivity(intent)
    }



    private fun initBoard() {
        // Adding the buttons to the board
        boardList.add(binding.btnA1)
        boardList.add(binding.btnA2)
        boardList.add(binding.btnA3)
        boardList.add(binding.btnB1)
        boardList.add(binding.btnB2)
        boardList.add(binding.btnB3)
        boardList.add(binding.btnC1)
        boardList.add(binding.btnC2)
        boardList.add(binding.btnC3)
    }

    fun boardTap(view: android.view.View)
    {
        if (view !is Button)
            return
        addToBoard(view)

        if(checkForVictory(EXS))
        {   // if Xs win, add a count to the X win and display message
            xCount++
            result("X's Win")
        }
        if(checkForVictory(OHS))
        {   // if Os win, add a count to O win and display message
            oCount++
            result("O's Win")
        }

        if(fullBoard())
        {   // if game is a draw
            result("DRAW")
        }
    }

    private fun checkForVictory(s: String): Boolean
    {   // Check Horizontal Wins
        if (match(binding.btnA1,s) && match(binding.btnA2,s) && match(binding.btnA3,s))
            return true
        if (match(binding.btnB1,s) && match(binding.btnB2,s) && match(binding.btnB3,s))
            return true
        if (match(binding.btnC1,s) && match(binding.btnC2,s) && match(binding.btnC3,s))
            return true

        // Check Vertical Wins
        if (match(binding.btnA1,s) && match(binding.btnB1,s) && match(binding.btnC1,s))
            return true
        if (match(binding.btnA2,s) && match(binding.btnB2,s) && match(binding.btnC2,s))
            return true
        if (match(binding.btnA3,s) && match(binding.btnB3,s) && match(binding.btnC3,s))
            return true

        // Check Diagnal Wins
        if (match(binding.btnA1,s) && match(binding.btnB2,s) && match(binding.btnC3,s))
            return true
        if (match(binding.btnA3,s) && match(binding.btnB2,s) && match(binding.btnC1,s))
            return true

        return false

    }

    // used to help with checkForVictory function
    private fun match(button: Button, symbol: String) = button.text == symbol

    private fun result(title: String)
    {   // display result of game in a message and resets board
        val message = "\nX's win total: $xCount\n\nO's win total: $oCount"
        AlertDialog.Builder(this)
            .setTitle(title)
            .setMessage(message)
            .setPositiveButton("Reset")
            {_,_ ->
                resetBoard()
            }
            .setCancelable(false)
            .show()
    }

    private fun resetBoard()
    {   // function to reset board
        for (button in boardList)
        {
            button.text = ""
        }

        if (firstTurn == Turn.EXS)
            firstTurn = Turn.OHS
        else if (firstTurn == Turn.OHS)
            firstTurn = Turn.EXS

        currentTurn = firstTurn
        setTurnLabel()
    }

    private fun fullBoard(): Boolean
    {   // Determines if board is full
        for(button in boardList){
            if(button.text == "")
                return false
        }
        return true

    }

    private fun addToBoard(button: Button)
    {    // Add X or O to Board depending on click and if button text is empty
        if (button.text != "")
            return
        if (currentTurn == Turn.EXS)
        {
            button.text = EXS
            currentTurn = Turn.OHS
        }
        else if (currentTurn == Turn.OHS)
        {
            button.text = OHS
            currentTurn = Turn.EXS
        }

        setTurnLabel()



    }

    private fun setTurnLabel()
    {   // display message for turn at top of game
        var turnText = ""
        if (currentTurn == Turn.EXS)
            turnText = "Turn is $EXS"
        else if (currentTurn == Turn.OHS)
            turnText = "Turn is $OHS"

        binding.turnView.text = turnText
    }

    companion object
    {   // used to help with input of X and O
        const val EXS = "X"
        const val OHS = "O"
    }
}